# Swanirvar v1.1.6 — Public Colab Package

## One-click public Colab usage

1. Open `Swanirvar_v1_1_6_Public_Colab.ipynb`.
2. Run all cells.
3. When prompted, upload this ZIP:
   `Swanirvar_v1_1_6_Public_Colab.zip`
4. The notebook runs entirely under `/content` and does NOT mount Google Drive.
5. At the end it prints and opens the temporary Colab-hosted Swanirvar URL.

## Optional cloud API credentials

The website can start without cloud credentials, but cloud AI/voice features need the
user's own credentials.

Create Colab Secrets for the services the user has access to, for example:

- `GEMINI_API_KEY`
- `BHASHINI_INFERENCE_API_KEY`
- `BHASHINI_TOKEN`
- Bhashini ASR/TTS service IDs
- `DATA_GOV_IN_API_KEY`
- `AGMARKNET_API_KEY`
- `ENAM_API_KEY`
- `ORS_API_KEY`

Secrets are read from the runtime and are never written into the ZIP.

## Important

- The Colab URL is temporary and changes after the runtime ends.
- Never publish API keys inside the notebook or ZIP.
- The notebook builds the browser frontend with Vite directly. It does not invoke
  the package's production `esbuild server.ts` bundling command.
- The existing FastAPI backend and evidence/ML/DL files are used unchanged.
