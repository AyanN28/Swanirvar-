import { GoogleGenAI } from '@google/genai';

export interface FormBoxDefinition {
  id: string;
  label: string;
  placeholder?: string;
  type?: string;
}

export interface CompanionRequest {
  message: string;
  pageContext?: 'home' | 'about' | 'auth' | 'dashboard' | 'feasibility' | 'dpr' | 'khata' | string;
  mode?: 'friend' | 'format_boxes' | 'read_outputs';
  targetBoxes?: FormBoxDefinition[];
  currentOutputSummary?: string;
  preferredLanguage?: string;
}

export interface CompanionResponse {
  detectedLanguage: {
    code: string;
    name: string;
    nativeName: string;
  };
  friendReply: string;
  structuredBoxes?: Record<string, string>;
  outputToRead: string;
}

let aiClient: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

export async function processVoiceWithGemini(
  req: CompanionRequest
): Promise<CompanionResponse> {
  const userText = (req.message || '').trim();
  const context = req.pageContext || 'home';
  const targetBoxes = req.targetBoxes || [];

  // Fallback if message is empty
  if (!userText) {
    return {
      detectedLanguage: { code: 'bn', name: 'Bengali', nativeName: 'বাংলা' },
      friendReply:
        'নমস্কার বন্ধু! আমি আপনার ভয়েস সাথী (Voice Saathi)। আপনার ব্যবসার স্বপ্ন বা প্রশ্নের কথা আমাকে বলুন, আমি শুনতে পাচ্ছি।',
      outputToRead:
        'নমস্কার বন্ধু! আমি আপনার ভয়েস সাথী। আপনার ব্যবসার কথা আমাকে বলুন।',
    };
  }

  const ai = getGeminiClient();

  if (ai) {
    try {
      const prompt = `You are "Voice Saathi" (ভয়েস সাথী / वॉइस साथी), a warm, empathetic, respectful, and intelligent friend and rural enterprise advisor under Aatmanirbhar Bharat.
You are interacting with an Indian entrepreneur, artisan, self-help group member, or citizen.

USER MESSAGE: "${userText}"
CURRENT APP PAGE / CONTEXT: "${context}"
ACTIVE FORM BOXES ON THIS PAGE: ${JSON.stringify(targetBoxes)}
PAGE CURRENT OUTPUT SUMMARY (if any): "${req.currentOutputSummary || 'None'}"

YOUR INSTRUCTIONS:
1. IDENTIFY SPOKEN LANGUAGE:
- Accurately determine the language of the user's message (Bengali 'bn', Hindi 'hi', Tamil 'ta', Telugu 'te', Marathi 'mr', Gujarati 'gu', Punjabi 'pa', Odia 'or', English 'en', etc.).
- Even if English script is used phonetically (Banglish or Hinglish), detect the intended vernacular language.

2. ACT LIKE A FRIEND:
- Reply warmly, encouragement-first, conversational, empathetic, and without robotic jargon.
- Treat the user like a close, trusted companion or guide ("নমস্কার বন্ধু!", "नमस्ते दोस्त!").
- Keep replies concise (2 to 4 friendly sentences) so it sounds natural when spoken aloud.

3. STRICT UNDERSTANDING & FORMATTING OF GIVEN BOXES:
- If the user is on a form page or if their speech contains details like enterprise name, district, capital amount, loan need, applicant name, phone number, customer name, transaction amount:
- STRICTLY extract and format these into JSON key-value pairs matching the field IDs in ACTIVE FORM BOXES (or standard field keys like 'businessName', 'district', 'category', 'projectCost', 'monthlyRevenue', 'fullName', 'mobileNumber', 'customerName', 'amount').
- Format currency cleanly (e.g., "500000" or "₹5,00,000").
- If a value was not mentioned, do not guess; omit it.

4. READ OUTPUTS SUMMARY:
- Provide an 'outputToRead' field in the user's detected language, formatted smoothly for Text-to-Speech narration.

Respond STRICTLY in valid JSON matching this schema:
{
  "detectedLanguage": {
    "code": "bn",
    "name": "Bengali",
    "nativeName": "বাংলা"
  },
  "friendReply": "friendly response in the user's detected language",
  "structuredBoxes": {
    "fieldName": "extracted value"
  },
  "outputToRead": "clear speech-ready narration text"
}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.3,
        },
      });

      const raw = response.text?.trim() || '';
      if (raw) {
        const parsed = JSON.parse(raw);
        return {
          detectedLanguage: parsed.detectedLanguage || {
            code: 'bn',
            name: 'Bengali',
            nativeName: 'বাংলা',
          },
          friendReply: parsed.friendReply || 'বন্ধু, আমি আপনার সাথে আছি।',
          structuredBoxes: parsed.structuredBoxes || {},
          outputToRead: parsed.outputToRead || parsed.friendReply,
        };
      }
    } catch (err) {
      console.warn('Gemini API call error, using deterministic companion engine:', err);
    }
  }

  // Deterministic Vernacular Companion Engine (Ensures 100% reliability)
  return fallbackCompanionProcessing(userText, context, targetBoxes);
}

function fallbackCompanionProcessing(
  userText: string,
  context: string,
  targetBoxes: FormBoxDefinition[]
): CompanionResponse {
  const lower = userText.toLowerCase();

  // Detect Language
  let code = 'en';
  let name = 'English';
  let nativeName = 'English';

  const bnRegex = /[\u0980-\u09FF]|ami|amra|tumi|apni|taka|bangla|namaskar|shuru|dokam|shilpo|kaje|hobe/i;
  const hiRegex = /[\u0900-\u097F]|namaste|mera|mujhe|chahiye|paisa|dukan|yojana|shuru|madad/i;

  if (bnRegex.test(userText) || lower.includes('bangla') || lower.includes('bengali')) {
    code = 'bn';
    name = 'Bengali';
    nativeName = 'বাংলা';
  } else if (hiRegex.test(userText) || lower.includes('hindi')) {
    code = 'hi';
    name = 'Hindi';
    nativeName = 'हिन्दी';
  }

  // Extract structured boxes (District, Amount, Business)
  const structuredBoxes: Record<string, string> = {};

  // Extract amounts (e.g. 5 lakh, 12,00,000, 5000)
  const lakhMatch = userText.match(/(\d+(?:\.\d+)?)\s*(?:lakh|লাখ|লাক|लाख)/i);
  if (lakhMatch) {
    const val = parseFloat(lakhMatch[1]) * 100000;
    structuredBoxes['projectCost'] = `₹${val.toLocaleString('en-IN')}`;
    structuredBoxes['amount'] = `₹${val.toLocaleString('en-IN')}`;
  } else {
    const numMatch = userText.match(/(?:₹|rs\.?|টাকা|रुपये)?\s*([0-9,]{4,})/i);
    if (numMatch) {
      structuredBoxes['projectCost'] = `₹${numMatch[1]}`;
      structuredBoxes['amount'] = `₹${numMatch[1]}`;
    }
  }

  // Extract phone numbers
  const phoneMatch = userText.match(/(?:\+91|0)?[6-9]\d{9}/);
  if (phoneMatch) {
    structuredBoxes['mobileNumber'] = phoneMatch[0];
    structuredBoxes['phone'] = phoneMatch[0];
  }

  // Extract popular districts
  const districts = [
    'Madurai', 'Kolkata', 'Hooghly', 'Howrah', 'Nadia', 'Burdwan', 'Murshidabad',
    'Bankura', 'Purulia', 'Birbhum', 'Malda', 'Jalandhar', 'Ludhiana', 'Pune', 'Thane'
  ];
  for (const d of districts) {
    if (new RegExp(d, 'i').test(userText)) {
      structuredBoxes['district'] = d;
      break;
    }
  }

  // Extract business category / name
  if (lower.includes('painting') || userText.includes('পেইন্টিং') || userText.includes('চিত্রকলা')) {
    structuredBoxes['businessName'] = 'Tanjore Painting & Art Studio';
    structuredBoxes['category'] = 'Handicrafts & Traditional Arts';
  } else if (lower.includes('dairy') || userText.includes('দুধ') || userText.includes('ডেয়ারি')) {
    structuredBoxes['businessName'] = 'Rural Dairy Farm';
    structuredBoxes['category'] = 'Dairy & Animal Husbandry';
  } else if (lower.includes('weaving') || lower.includes('handloom') || userText.includes('তাঁত') || userText.includes('শাড়ি')) {
    structuredBoxes['businessName'] = 'Traditional Handloom Weaving';
    structuredBoxes['category'] = 'Textiles & Handlooms';
  } else if (lower.includes('sweet') || userText.includes('মিষ্টি') || userText.includes('খাবার')) {
    structuredBoxes['businessName'] = 'Bengali Sweets & Confectionery';
    structuredBoxes['category'] = 'Food Processing';
  }

  let friendReply = '';
  let outputToRead = '';

  if (code === 'bn') {
    friendReply = `নমস্কার বন্ধু! আপনার কথাটি আমি খুব মন দিয়ে বুঝেছি। আপনার ব্যবসার প্রতিটি পদক্ষেপে আমি বন্ধুর মতো সাহায্য করব। ${
      Object.keys(structuredBoxes).length > 0
        ? 'আমি আপনার দেওয়া তথ্যগুলো নির্দিষ্ট বক্সে সাজিয়ে দিয়েছি।'
        : 'আপনি সরকারি মুদ্রা ঋণ ও নাবার্ড প্রকল্পের সম্পূর্ণ সহায়তা পেতে পারেন।'
    }`;
    outputToRead = friendReply;
  } else if (code === 'hi') {
    friendReply = `नमस्ते दोस्त! मैंने आपकी बात समझ ली है। आपके उद्यम को आगे बढ़ाने में मैं हमेशा आपका साथ दूंगा। ${
      Object.keys(structuredBoxes).length > 0
        ? 'मैंने आपकी जानकारी को दिए गए बॉक्स में भर दिया है।'
        : 'आप मुद्रा लोन और सरकारी सब्सिडी का पूरा लाभ ले सकते हैं।'
    }`;
    outputToRead = friendReply;
  } else {
    friendReply = `Hello friend! I am your Swanirvar companion. I have understood your enterprise request. ${
      Object.keys(structuredBoxes).length > 0
        ? 'I have formatted the details into the form boxes for you.'
        : 'You can explore verified government subsidies and bank capital schemes here.'
    }`;
    outputToRead = friendReply;
  }

  return {
    detectedLanguage: { code, name, nativeName },
    friendReply,
    structuredBoxes,
    outputToRead,
  };
}
