import React, { useEffect, useRef } from 'react';
import { useLanguage } from '../context/LanguageContext';

export const StatisticsSection: React.FC = () => {
  const { t } = useLanguage();
  const statsTrackRef = useRef<HTMLDivElement | null>(null);
  const animatedRef = useRef<boolean>(false);

  useEffect(() => {
    function formatIndianNumber(x: number): string {
      const s = Math.round(x).toString();
      if (s.length <= 3) return s;
      const lastThree = s.substring(s.length - 3);
      const otherNumbers = s.substring(0, s.length - 3);
      return otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ',') + ',' + lastThree;
    }

    const triggerStatsCounterAnimation = () => {
      if (animatedRef.current) return;
      animatedRef.current = true;

      const metricValues = statsTrackRef.current?.querySelectorAll<HTMLElement>('.stat-metric-value');
      if (!metricValues) return;

      metricValues.forEach((el) => {
        const target = parseFloat(el.dataset.final || '0');
        const isIndian = el.dataset.format === 'indian';
        const decimals = parseInt(el.dataset.decimals || '0', 10);
        const duration = 1600;
        const startCountTime = performance.now();

        function updateVal(currentTime: number) {
          const elapsed = currentTime - startCountTime;
          const progress = Math.min(1, elapsed / duration);
          const ease = 1 - Math.pow(1 - progress, 4);
          const current = target * ease;

          el.textContent = isIndian
            ? formatIndianNumber(current)
            : current.toFixed(decimals);

          if (progress < 1) {
            requestAnimationFrame(updateVal);
          } else {
            el.textContent = isIndian
              ? formatIndianNumber(target)
              : target.toFixed(decimals);
          }
        }

        requestAnimationFrame(updateVal);
      });
    };

    const currentTrack = statsTrackRef.current;
    if (!currentTrack) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            triggerStatsCounterAnimation();
          }
        });
      },
      { threshold: 0.2 }
    );

    observer.observe(currentTrack);

    return () => {
      observer.disconnect();
    };
  }, []);

  return (
    <section
      aria-label="National Administrative Scale and Telemetry"
      className="stats-strip-section reveal visible border-y-2 border-[#191970]/30 py-8 px-4 sm:px-8 bg-[#faf6ee]"
      id="statistics"
    >
      <div className="stats-strip-container">
        {/* Brand Col */}
        <div className="stats-brand-col">
          <div className="stats-handwritten-title">
            <span>{t('Statistics')}</span>
            <svg
              aria-hidden="true"
              className="stats-curved-arrow"
              fill="none"
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2.5"
              viewBox="0 0 54 36"
            >
              <path d="M4 8 C14 26, 26 34, 38 20 C42 15, 46 8, 48 4" />
              <path d="M38 4 L48 4 L48 14" />
            </svg>
          </div>
          <div className="stats-sub-beacon">
            <span className="beacon-dot" />
            <span>{t('National Scale Telemetry')}</span>
          </div>
        </div>

        {/* 4 Requested Metrics Track (All old metrics removed) */}
        <div className="stats-metrics-track" id="stats-counter-track" ref={statsTrackRef}>
          {/* Card 1: National Administrative Scale */}
          <div className="stat-metric-card highlight">
            <div className="stat-metric-number-row">
              <span
                className="stat-metric-value"
                data-decimals="0"
                data-final="36"
              >
                36
              </span>
              <span className="stat-metric-suffix">{t('States & UTs')}</span>
            </div>
            <div className="stat-metric-label">{t('National Administrative Scale')}</div>
            <div className="stat-metric-subtext">
              {t('36 (28 States and 8 Union Territories)')}
            </div>
          </div>

          {/* Card 2: Total Village Reach */}
          <div className="stat-metric-card">
            <div className="stat-metric-number-row">
              <span
                className="stat-metric-value"
                data-decimals="2"
                data-final="6.64"
              >
                6.64
              </span>
              <span className="stat-metric-suffix">{t('Lakhs')}</span>
            </div>
            <div className="stat-metric-label">{t('Total Village Reach')}</div>
            <div className="stat-metric-subtext">
              {t('Approximately 6.64 Lakhs (664,369 recorded rural jurisdictions across India)')}
            </div>
          </div>

          {/* Card 3: Grassroots Digital Infrastructure */}
          <div className="stat-metric-card">
            <div className="stat-metric-number-row">
              <span className="text-sm font-bold text-[#14120e] mr-1 self-center">{t('Over')}</span>
              <span
                className="stat-metric-value"
                data-decimals="1"
                data-final="2.5"
              >
                2.5
              </span>
              <span className="stat-metric-suffix">{t('Lakh CSCs')}</span>
            </div>
            <div className="stat-metric-label">{t('Grassroots Digital Infrastructure')}</div>
            <div className="stat-metric-subtext">
              {t('Over 2.5 Lakh Common Service Centres (CSCs) deployed across Gram Panchayats nationwide')}
            </div>
          </div>

          {/* Card 4: Field Agent Workforce */}
          <div className="stat-metric-card">
            <div className="stat-metric-number-row">
              <span className="text-sm font-bold text-[#14120e] mr-1 self-center">{t('Over')}</span>
              <span
                className="stat-metric-value"
                data-decimals="1"
                data-final="5.5"
              >
                5.5
              </span>
              <span className="text-sm font-bold text-[#FF671F] mx-1 self-center">{t('to')}</span>
              <span
                className="stat-metric-value"
                data-decimals="0"
                data-final="6"
              >
                6
              </span>
              <span className="stat-metric-suffix">{t('Lakh+ VLEs')}</span>
            </div>
            <div className="stat-metric-label">{t('Field Agent Workforce')}</div>
            <div className="stat-metric-subtext">
              {t('Over 5.5 to 6 Lakh+ active Village Level Entrepreneurs (VLEs) operating under the CSC digital framework')}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
