import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { processVoiceWithGemini } from './src/server/geminiCompanion';
import { translateTextsBatch } from './src/server/translationService';
import {
  transcribeAudioWithGemini,
  generateSpeechWithGemini,
} from './src/server/geminiAudioService';
import {
  reverseGeocodeOsm,
  fetchOverpassPois,
  fetchCensusAndEconomicData,
  fetchMandiPriceAnalysis,
} from './src/server/spatialDataService';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '20mb' }));

  // API routes FIRST
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', time: new Date().toISOString() });
  });

  // 1. Reverse Geocode via OSM Nominatim
  app.get('/api/location/reverse-geocode', async (req, res) => {
    try {
      const lat = parseFloat(req.query.lat as string) || 9.9252;
      const lng = parseFloat(req.query.lng as string) || 78.1198;
      const geocoded = await reverseGeocodeOsm(lat, lng);
      res.json(geocoded);
    } catch (err: any) {
      res.status(500).json({ error: err?.message || 'Geocoding failed' });
    }
  });

  // 2. Overpass API Real POIs & Competition Scan
  app.post('/api/location/scan-pois', async (req, res) => {
    try {
      const { lat, lng, radiusKm, businessType } = req.body;
      const parsedLat = parseFloat(lat) || 9.9252;
      const parsedLng = parseFloat(lng) || 78.1198;
      const parsedRadius = (parseInt(radiusKm, 10) || 10) as 5 | 10 | 15;
      const result = await fetchOverpassPois(parsedLat, parsedLng, parsedRadius, businessType || 'Rural Enterprise');
      res.json(result);
    } catch (err: any) {
      res.status(500).json({ error: err?.message || 'Spatial POI scan failed' });
    }
  });

  // 3. Census 2011 & World Bank Per Capita Income API
  app.get('/api/data/census-economic', async (req, res) => {
    try {
      const district = (req.query.district as string) || 'Madurai';
      const state = (req.query.state as string) || 'Tamil Nadu';
      const data = await fetchCensusAndEconomicData(district, state);
      res.json(data);
    } catch (err: any) {
      res.status(500).json({ error: err?.message || 'Economic data retrieval failed' });
    }
  });

  // 4. Mandi Near Me & Agmarknet Pricing
  app.get('/api/data/mandis-pricing', async (req, res) => {
    try {
      const lat = parseFloat(req.query.lat as string) || 9.9252;
      const lng = parseFloat(req.query.lng as string) || 78.1198;
      const district = (req.query.district as string) || 'Madurai';
      const state = (req.query.state as string) || 'Tamil Nadu';
      const businessType = (req.query.businessType as string) || 'Rural Enterprise';
      const mandis = await fetchMandiPriceAnalysis(lat, lng, district, state, businessType);
      res.json({ mandis });
    } catch (err: any) {
      res.status(500).json({ error: err?.message || 'Mandi pricing query failed' });
    }
  });

  // 5. Gemini Voice Recognition (Speech-to-Text)
  app.post('/api/voice/transcribe', async (req, res) => {
    try {
      const { audio, mimeType, languageHint } = req.body;
      if (!audio) {
        return res.status(400).json({ error: 'Audio data is required' });
      }
      const result = await transcribeAudioWithGemini(audio, mimeType, languageHint);
      res.json(result);
    } catch (err: any) {
      console.error('Transcription route error:', err);
      res.status(500).json({ error: err?.message || 'Speech transcription failed' });
    }
  });

  // 6. Gemini Voice Output (Text-to-Speech)
  app.post('/api/voice/tts', async (req, res) => {
    try {
      const { text, voiceName } = req.body;
      if (!text) {
        return res.status(400).json({ error: 'Text is required for TTS' });
      }
      const result = await generateSpeechWithGemini(text, voiceName || 'Kore');
      if (!result) {
        return res.json({ fallback: true });
      }
      res.json(result);
    } catch (err: any) {
      console.warn('TTS route error:', err);
      res.json({ fallback: true, error: err?.message });
    }
  });

  // 7. Gemini Voice Saathi Companion & Intent Processor
  app.post(['/api/voice-assistant', '/api/companion/chat'], async (req, res) => {
    try {
      const result = await processVoiceWithGemini(req.body);
      res.json(result);
    } catch (err: any) {
      console.error('Voice assistant error:', err);
      res.status(500).json({ error: err?.message || 'Error processing speech with Gemini' });
    }
  });

  // 8. Gemini Dynamic Universal UI Translation Batch
  app.post('/api/translate-batch', async (req, res) => {
    try {
      const { texts, targetLang } = req.body;
      const translations = await translateTextsBatch(texts, targetLang);
      res.json({ translations });
    } catch (err: any) {
      res.status(500).json({ error: err?.message || 'Translation error' });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`SWANIRVAR Server running on http://localhost:${PORT}`);
  });
}

startServer();
