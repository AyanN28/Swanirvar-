# Swanirvar v1.1.6 Full-Stack Corrected

This corrected package preserves the `swanirvar (1)` frontend exactly under `frontend/` and the v1.1.6 FastAPI backend under `backend/`.

The frontend's own `index.html`, `src/index.css`, `vite.config.ts`, `src/utils/domTranslator.ts`, and server-side integration files remain inside `frontend/`.

The root launcher starts the FastAPI backend and the original frontend server from the `frontend` directory. Node dependencies are installed in the runtime environment (Colab `/content`), not Google Drive.
