from __future__ import annotations
import os, socket, subprocess, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FRONTEND = ROOT / 'frontend'
RUNTIME = ROOT / 'runtime'
RUNTIME.mkdir(exist_ok=True)
BACKEND_PORT = int(os.getenv('SWANIRVAR_BACKEND_PORT','8000'))
UI_PORT = int(os.getenv('SWANIRVAR_UI_PORT','3000'))

def wait_port(port, timeout=60):
    end=time.time()+timeout
    while time.time()<end:
        try:
            with socket.create_connection(('127.0.0.1',port),timeout=1): return True
        except OSError: time.sleep(.5)
    return False

env=os.environ.copy()
env['SWANIRVAR_UI_PORT']=str(UI_PORT)
env['SWANIRVAR_BACKEND_URL']=env.get('SWANIRVAR_BACKEND_URL',f'http://127.0.0.1:{BACKEND_PORT}')
env['NODE_ENV']='production'

backend_log=open(RUNTIME/'backend.log','w',encoding='utf-8')
backend=subprocess.Popen([sys.executable,'-m','uvicorn','backend.app:app','--host','0.0.0.0','--port',str(BACKEND_PORT)],cwd=ROOT,env=env,stdout=backend_log,stderr=subprocess.STDOUT)
if not wait_port(BACKEND_PORT):
    backend_log.flush(); raise RuntimeError((RUNTIME/'backend.log').read_text(errors='replace')[-12000:])

# Build the original frontend in its own directory, where its index.html and vite.config.ts live.
build=subprocess.run(['npm','run','build'],cwd=FRONTEND,env=env,text=True,capture_output=True)
(RUNTIME/'frontend-build.log').write_text((build.stdout or '')+'\n'+(build.stderr or ''),encoding='utf-8')
if build.returncode != 0:
    backend.terminate()
    raise RuntimeError((RUNTIME/'frontend-build.log').read_text(errors='replace')[-16000:])

frontend_log=open(RUNTIME/'frontend.log','w',encoding='utf-8')
# Start the ORIGINAL frontend server from its own directory.
frontend=subprocess.Popen(['node','-e',"import('./server.ts')"],cwd=FRONTEND,env=env,stdout=frontend_log,stderr=subprocess.STDOUT)
if not wait_port(UI_PORT):
    frontend_log.flush(); backend.terminate()
    raise RuntimeError((RUNTIME/'frontend.log').read_text(errors='replace')[-16000:])

print('SWANIRVAR FULL-STACK RUNNING')
print(f'Backend:  http://127.0.0.1:{BACKEND_PORT}')
print(f'Frontend: http://127.0.0.1:{UI_PORT}')
print(f'Frontend source: {FRONTEND}')
print(f'Runtime logs: {RUNTIME}')
print('Press Ctrl+C to stop both services.')
try:
    while True:
        if backend.poll() is not None: raise RuntimeError('Backend exited. See runtime/backend.log')
        if frontend.poll() is not None: raise RuntimeError('Frontend exited. See runtime/frontend.log')
        time.sleep(1)
except KeyboardInterrupt:
    pass
finally:
    for p in (frontend,backend):
        if p.poll() is None: p.terminate()
    for p in (frontend,backend):
        try: p.wait(timeout=8)
        except subprocess.TimeoutExpired: p.kill()
    backend_log.close(); frontend_log.close()
