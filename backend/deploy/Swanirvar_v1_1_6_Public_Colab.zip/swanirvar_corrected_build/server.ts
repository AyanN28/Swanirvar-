import path from 'node:path';
import { chdir } from 'node:process';

const frontendRoot = path.resolve(process.cwd(), 'frontend');
chdir(frontendRoot);
await import('./frontend/server.ts');
