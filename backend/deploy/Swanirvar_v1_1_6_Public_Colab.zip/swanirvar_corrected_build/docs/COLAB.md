# Colab

Upload this ZIP in the existing `Swanirvar_v1_1_6_FullStack_Colab.ipynb`.

The runtime should extract the project, install Python requirements at runtime, run npm in the project runtime, and launch `run_fullstack.py`.

Do not install `node_modules` on `/content/drive` because native packages such as esbuild may fail with EACCES there.
