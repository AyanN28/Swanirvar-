# API Integration

The frontend-native server in `frontend/server.ts` provides:
- `/api/health`
- `/api/location/reverse-geocode`
- `/api/location/scan-pois`
- `/api/data/census-economic`
- `/api/data/mandis-pricing`
- `/api/voice/transcribe`
- `/api/voice/tts`
- `/api/voice-assistant`
- `/api/companion/chat`
- `/api/translate-batch`

The FastAPI backend under `backend/` remains the Swanirvar decision/evidence/7D/finance/ML-DL backend.
