# ML/DL

The v1.1.6 backend's ML/DL registry and advisory boundary are preserved. Deterministic 7D logic remains the decision authority. Do not fabricate models or evidence when data/connectors are unavailable.
